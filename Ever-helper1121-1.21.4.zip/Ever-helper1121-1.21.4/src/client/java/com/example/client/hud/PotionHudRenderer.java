package com.example.client.hud;

import com.example.client.config.PotionHudConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import java.util.List;

public final class PotionHudRenderer {
    private static final int MARGIN = 8, HEIGHT = 30, GAP = 4, BLOCK_GAP = 14;
    private final PotionHudConfig config;

    public PotionHudRenderer(PotionHudConfig config) { this.config = config; }

    @SuppressWarnings("deprecation")
    public void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!config.enabled || client.player == null || client.options.hudHidden) return;
        List<PotionHudModel.Effect> effects = client.player.getStatusEffects().stream().map(instance -> {
            var effect = instance.getEffectType().value();
            return new PotionHudModel.Effect(Registries.STATUS_EFFECT.getId(effect).toString(),
                    effect.getName().getString(), instance.getAmplifier(),
                    instance.isInfinite() ? -1 : instance.getDuration(), effect.getColor() | 0xFF000000);
        }).toList();
        var cards = PotionHudModel.build(effects, config.presets, config.individualOverrides);
        int nextY = drawBlock(context, client, cards.regular(), MARGIN);
        if (!cards.regular().isEmpty()) nextY += BLOCK_GAP;
        drawBlock(context, client, cards.custom(), nextY);
    }

    // Rows grow from the upper right and wrap inside the scaled GUI width.
    private int drawBlock(DrawContext context, MinecraftClient client, List<PotionHudModel.Card> cards, int y) {
        if (cards.isEmpty()) return y;
        int available = context.getScaledWindowWidth() - MARGIN * 2;
        if (available < 40) return y;
        int width = Math.min(180, available);
        int columns = Math.max(1, (available + GAP) / (width + GAP));
        for (int i = 0; i < cards.size(); i++) {
            var card = cards.get(i);
            int x = context.getScaledWindowWidth() - MARGIN - width - (i % columns) * (width + GAP);
            int top = y + (i / columns) * (HEIGHT + GAP);
            if (top + HEIGHT > context.getScaledWindowHeight() - MARGIN) break;
            context.fill(x, top, x + width, top + HEIGHT, 0xCC111722);
            context.drawBorder(x, top, width, HEIGHT, card.color());
            String name = card.name();
            int textWidth = width - 12;
            if (client.textRenderer.getWidth(name) > textWidth) {
                name = client.textRenderer.trimToWidth(name, Math.max(0, textWidth - client.textRenderer.getWidth("…"))) + "…";
            }
            context.drawTextWithShadow(client.textRenderer, name, x + 6, top + 5, card.color());
            String detail = card.level() > 0 ? "Lv. " + card.level() : "";
            context.drawTextWithShadow(client.textRenderer, detail, x + 6, top + 17, 0xFFCED6E0);
            String timer = PotionHudModel.timer(card.duration());
            context.drawTextWithShadow(client.textRenderer, timer,
                    x + width - 6 - client.textRenderer.getWidth(timer), top + 17, 0xFFFFFFFF);
        }
        return y + ((cards.size() + columns - 1) / columns) * (HEIGHT + GAP) - GAP;
    }
}
