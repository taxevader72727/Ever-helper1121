package com.example.client.hud;

import com.example.client.config.*;
import java.util.*;

/** Pure matching and presentation logic: no game state is changed. */
public final class PotionHudModel {
    private PotionHudModel() {}
    public record Effect(String id, String name, int amplifier, int duration, int color) {}
    // level 0 means a merged combination with no single meaningful level.
    public record Card(String name, int level, int duration, int color) {}
    public record Cards(List<Card> regular, List<Card> custom) {}

    public static Cards build(Collection<Effect> effects, List<PotionPreset> presets,
                              Map<String, EffectOverride> overrides) {
        Map<String, Effect> active = new TreeMap<>();
        for (Effect effect : effects) {
            if (effect.duration() == -1 || effect.duration() > 0) active.put(effect.id(), effect);
        }
        Set<String> used = new HashSet<>();
        List<Card> custom = new ArrayList<>();
        for (PotionPreset preset : presets) {
            if (preset.requiredEffects.isEmpty()) continue;
            boolean matches = preset.requiredEffects.stream().allMatch(required -> {
                Effect effect = active.get(required.effectId);
                return effect != null && effect.amplifier() == required.amplifier && !used.contains(effect.id());
            });
            if (!matches) continue;
            List<Effect> members = preset.requiredEffects.stream().map(r -> active.get(r.effectId)).toList();
            if ("SEPARATE".equals(preset.mode)) {
                for (Effect effect : members) {
                    EffectOverride override = preset.separateOverrides.get(effect.id());
                    if (override == null) override = new EffectOverride();
                    custom.add(new Card(override.nameOr(effect.name()), effect.amplifier() + 1,
                            effect.duration(), override.getColorArgb(preset.merged.getColorArgb(effect.color()))));
                }
            } else {
                int duration = members.stream().anyMatch(e -> e.duration() == -1) ? -1 :
                        members.stream().mapToInt(Effect::duration).max().orElse(0);
                custom.add(new Card(preset.merged.nameOr(preset.id), 0, duration,
                        preset.merged.getColorArgb(members.get(0).color())));
            }
            members.forEach(e -> used.add(e.id()));
        }
        List<Card> regular = new ArrayList<>();
        for (Effect effect : active.values()) {
            if (used.contains(effect.id())) continue;
            EffectOverride override = overrides.get(effect.id());
            if (override == null) override = new EffectOverride();
            regular.add(new Card(override.nameOr(effect.name()), effect.amplifier() + 1,
                    effect.duration(), override.getColorArgb(effect.color())));
        }
        return new Cards(List.copyOf(regular), List.copyOf(custom));
    }

    public static String timer(int ticks) {
        if (ticks == -1) return "∞";
        long seconds = (Math.max(0L, ticks) + 19) / 20;
        return String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60);
    }
}
