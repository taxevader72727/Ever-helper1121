package com.example.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class PotionHudConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Logger LOGGER = LoggerFactory.getLogger("potionhud");
    public boolean enabled = true;
    public boolean hideVanillaHud = true;
    public Map<String, EffectOverride> individualOverrides = new LinkedHashMap<>();
    public List<PotionPreset> presets = new ArrayList<>();

    public static PotionHudConfig load() {
        return load(FabricLoader.getInstance().getConfigDir().resolve("potionhud.json"));
    }

    public static PotionHudConfig load(Path path) {
        if (!Files.exists(path)) {
            PotionHudConfig defaults = defaults();
            try {
                Files.createDirectories(path.toAbsolutePath().getParent());
                // Never replace an existing user file, even if it appeared during loading.
                Files.writeString(path, GSON.toJson(defaults) + "\n", StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            } catch (IOException e) {
                LOGGER.warn("Could not create potion HUD config at {}", path, e);
            }
            return defaults;
        }
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            PotionHudConfig config = GSON.fromJson(reader, PotionHudConfig.class);
            if (config == null) throw new IllegalArgumentException("Config must be an object");
            config.validate();
            return config;
        } catch (IOException | RuntimeException e) {
            // Keep malformed files intact so users can fix their settings.
            LOGGER.error("Invalid potion HUD config at {}; using defaults without overwriting it", path, e);
            return defaults();
        }
    }

    public static PotionHudConfig defaults() {
        try (InputStream stream = PotionHudConfig.class.getResourceAsStream("/potionhud-default.json")) {
            if (stream == null) throw new IllegalStateException("Missing potionhud-default.json");
            PotionHudConfig config = GSON.fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), PotionHudConfig.class);
            config.validate();
            return config;
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public void validate() {
        if (individualOverrides == null || presets == null)
            throw new IllegalArgumentException("Overrides and presets cannot be null");
        Set<String> ids = new HashSet<>();
        for (PotionPreset preset : presets) {
            if (preset == null || preset.id == null || preset.id.isBlank() || !ids.add(preset.id))
                throw new IllegalArgumentException("Preset IDs must be unique and non-empty");
            if (!"MERGED".equals(preset.mode) && !"SEPARATE".equals(preset.mode))
                throw new IllegalArgumentException("Invalid mode for " + preset.id);
            if (preset.requiredEffects == null || preset.requiredEffects.isEmpty())
                throw new IllegalArgumentException("Empty requirements for " + preset.id);
            Set<String> effects = new HashSet<>();
            for (RequiredEffect effect : preset.requiredEffects) {
                if (effect == null || effect.effectId == null ||
                        !effect.effectId.matches("[a-z0-9_.-]+:[a-z0-9/._-]+") ||
                        !effects.add(effect.effectId) || effect.amplifier < 0 || effect.amplifier > 255)
                    throw new IllegalArgumentException("Invalid requirement for " + preset.id);
            }
            if (preset.merged == null) preset.merged = new EffectOverride();
            if (preset.separateOverrides == null) preset.separateOverrides = new LinkedHashMap<>();
        }
    }
}
