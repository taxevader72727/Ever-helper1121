package com.example.client;

import com.example.client.config.PotionHudConfig;
import com.example.client.hud.PotionHudRenderer;
import net.fabricmc.api.ClientModInitializer;

public class ExampleModClient implements ClientModInitializer {
    private static PotionHudConfig config;
    @Override
    public void onInitializeClient() {
        config = PotionHudConfig.load();
        new PotionHudRenderer(config).register();
    }
    public static boolean hidesVanillaEffects() {
        return config != null && config.enabled && config.hideVanillaHud;
    }
}
