package com.example.client.config;

public class RequiredEffect {
    public String effectId;
    // Game level minus one: level IV = amplifier 3.
    public int amplifier;
}
