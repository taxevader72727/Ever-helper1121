package com.example.client.config;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PotionPreset {
    public String id;
    public String mode = "MERGED";
    public List<RequiredEffect> requiredEffects = new ArrayList<>();
    public EffectOverride merged = new EffectOverride();
    public Map<String, EffectOverride> separateOverrides = new LinkedHashMap<>();
}
