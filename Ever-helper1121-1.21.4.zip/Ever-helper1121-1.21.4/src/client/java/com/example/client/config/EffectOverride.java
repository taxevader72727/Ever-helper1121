package com.example.client.config;

public class EffectOverride {
    public String displayName;
    public String color;

    public String nameOr(String fallback) {
        return displayName == null || displayName.isBlank() ? fallback : displayName;
    }

    public int getColorArgb(int fallback) {
        if (color == null) return fallback;
        String hex = color.trim();
        if (!hex.matches("#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?")) return fallback;
        long value = Long.parseLong(hex.substring(1), 16);
        return hex.length() == 7 ? (int) value | 0xFF000000 : (int) value;
    }
}
