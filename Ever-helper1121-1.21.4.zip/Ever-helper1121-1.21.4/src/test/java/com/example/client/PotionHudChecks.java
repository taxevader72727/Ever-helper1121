package com.example.client;

import com.example.client.config.*;
import com.example.client.hud.PotionHudModel;
import com.example.client.hud.PotionHudModel.Effect;
import java.nio.file.*;
import java.util.*;

/** Behavior checks runnable without launching Minecraft or adding a test framework. */
public final class PotionHudChecks {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    private static List<Effect> effects(PotionPreset p) {
        List<Effect> result = new ArrayList<>();
        for (int i = 0; i < p.requiredEffects.size(); i++) {
            RequiredEffect r = p.requiredEffects.get(i);
            result.add(new Effect(r.effectId, r.effectId, r.amplifier, (i + 1) * 200, 0xFF123456));
        }
        return result;
    }
    public static void main(String[] args) throws Exception {
        PotionHudConfig config = PotionHudConfig.defaults();
        check(config.presets.size() == 7, "Seven default presets");
        for (PotionPreset preset : config.presets) {
            List<Effect> active = effects(preset);
            var merged = PotionHudModel.build(active, config.presets, Map.of());
            check(merged.regular().isEmpty() && merged.custom().size() == 1, "Merged " + preset.id);
            check(merged.custom().get(0).duration() == active.size() * 200, "Maximum timer " + preset.id);
            check(merged.custom().get(0).level() == 0, "No invented combo level");
            var missing = PotionHudModel.build(active.subList(1, active.size()), List.of(preset), Map.of());
            check(missing.custom().isEmpty() && missing.regular().size() == active.size() - 1, "Missing member " + preset.id);
            Effect first = active.get(0);
            active.set(0, new Effect(first.id(), first.name(), first.amplifier() + 1, first.duration(), first.color()));
            check(PotionHudModel.build(active, List.of(preset), Map.of()).custom().isEmpty(), "Exact level " + preset.id);
            active = effects(preset);
            preset.mode = "SEPARATE";
            var separate = PotionHudModel.build(active, List.of(preset), Map.of());
            check(separate.custom().size() == active.size() && separate.regular().isEmpty(), "Separate " + preset.id);
            check(separate.custom().get(0).name().equals(preset.separateOverrides.get(first.id()).displayName), "Separate name");
            check(separate.custom().get(0).duration() == first.duration(), "Separate timer");
            check(separate.custom().get(0).level() == first.amplifier() + 1, "Visible level");
            preset.mode = "MERGED";
        }
        PotionPreset assassin = config.presets.get(0), holy = config.presets.get(1);
        check(holy.requiredEffects.stream().noneMatch(r -> r.effectId.contains("instant")), "Holy water excludes instant healing");
        List<Effect> both = effects(assassin);
        both.addAll(effects(holy));
        both.add(new Effect("minecraft:night_vision", "Night Vision", 0, 1000, 0xFF123456));
        var multiple = PotionHudModel.build(both, config.presets, Map.of());
        check(multiple.custom().size() == 2 && multiple.regular().size() == 1, "Two combos plus regular");
        var overlap = PotionHudModel.build(effects(assassin), List.of(assassin, assassin), Map.of());
        check(overlap.custom().size() == 1, "First preset owns overlapping effects");
        List<Effect> infinite = effects(assassin);
        var e = infinite.get(0);
        infinite.set(0, new Effect(e.id(), e.name(), e.amplifier(), -1, e.color()));
        check(PotionHudModel.build(infinite, config.presets, Map.of()).custom().get(0).duration() == -1, "Infinite merged timer");
        infinite.set(0, new Effect(e.id(), e.name(), e.amplifier(), 0, e.color()));
        check(PotionHudModel.build(infinite, config.presets, Map.of()).custom().isEmpty(), "Expired effect does not match");
        check(PotionHudModel.build(List.of(), config.presets, Map.of()).custom().isEmpty(), "No stale cards after clearing");
        EffectOverride override = new EffectOverride();
        override.displayName = "Custom"; override.color = "#FF5555";
        var normal = PotionHudModel.build(List.of(e), List.of(), Map.of(e.id(), override)).regular().get(0);
        check(normal.name().equals("Custom") && normal.color() == 0xFFFF5555, "Individual override");
        override.color = "bad";
        check(override.getColorArgb(42) == 42, "Invalid color fallback");
        override.color = "#80112233";
        check(override.getColorArgb(42) == 0x80112233, "ARGB color");
        check(PotionHudModel.timer(-1).equals("∞"), "Infinite format");
        check(PotionHudModel.timer(1200).equals("01:00"), "Minute format");
        check(PotionHudModel.timer(1).equals("00:01"), "No zero while active");
        check(PotionHudModel.timer(0).equals("00:00"), "Zero format");
        Path folder = Files.createTempDirectory("potionhud-checks-");
        try {
            Path file = folder.resolve("potionhud.json");
            check(PotionHudConfig.load(file).presets.size() == 7 && Files.exists(file), "Generate config");
            String custom = "{\"enabled\":false,\"individualOverrides\":{},\"presets\":[]}";
            Files.writeString(file, custom);
            check(!PotionHudConfig.load(file).enabled, "Read custom config");
            check(Files.readString(file).equals(custom), "Do not overwrite user config");
            for (String bad : List.of("{broken", "null", "{\"presets\":[null]}", "{\"presets\":[{\"id\":\"x\",\"requiredEffects\":[]}]}")) {
                Files.writeString(file, bad);
                check(PotionHudConfig.load(file).presets.size() == 7, "Invalid config falls back");
                check(Files.readString(file).equals(bad), "Invalid config preserved");
            }
            Files.delete(file);
        } finally { Files.delete(folder); }
        System.out.println("Potion HUD: " + checks + " checks passed.");
    }
}
